import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { PutCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";
import { v4 as uuidv4 } from 'uuid';

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const tableName = process.env.TABLE_NAME;
const lambda_get_items_by_id = process.env.LAMBDA_GET_ITEMS_BY_ID;

export const handler = async (event) => {
  const { firstName, lastName, age } = JSON.parse(event.body);
  const id = uuidv4();
  console.log("UUID:", id)
  console.log(event.body);

  const command = new PutCommand({
    TableName: tableName,
    Item: {
      ID: id,
      CUSTOMER_FIRST_NAME: { S: firstName },
      CUSTOMER_LAST_NAME: { S: lastName },
      CUSTOMER_AGE: { N: age.toString() },
    },
  });

  try {
    const response = await docClient.send(command);
    return {
      statusCode: 200,
      body: JSON.stringify(response),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify(err),
    };
  }
};
