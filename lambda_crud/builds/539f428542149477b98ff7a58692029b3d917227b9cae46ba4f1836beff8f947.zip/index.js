import { DynamoDBClient } from "@aws-sdk/client-dynamodb";
import { PutCommand, DynamoDBDocumentClient } from "@aws-sdk/lib-dynamodb";

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);
const tableName = process.env.TABLE_NAME;

export const handler = async (event) => {
  const { username, firstName, lastName, age } = JSON.parse(event.body);

  const command = new PutCommand({
    TableName: tableName,
    Item: {
      USERNAME: username ,
      CUSTOMER_FIRST_NAME: { S: firstName },
      CUSTOMER_LAST_NAME: { S: lastName },
      CUSTOMER_AGE: { N: age.toString() },
    },
  });

  try {
    const response = await docClient.send(command);
    return {
      statusCode: 200,
      body: JSON.stringify(response),
    };
  } catch (err) {
    return {
      statusCode: 500,
      body: JSON.stringify(err),
    };
  }
};
